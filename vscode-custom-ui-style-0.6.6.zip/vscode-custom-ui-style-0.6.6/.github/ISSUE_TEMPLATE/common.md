---
name: Common
about: Basic issue template
title: ''
labels: ''
assignees: ''

---

- [ ] **I have read the [Claim](https://github.com/subframe7536/vscode-custom-ui-style?tab=readme-ov-file#claim)**
